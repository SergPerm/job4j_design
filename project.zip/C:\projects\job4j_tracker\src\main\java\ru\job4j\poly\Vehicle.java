package ru.job4j.poly;

public interface Vehicle {
    public void move();
}
